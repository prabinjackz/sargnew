#define VERSION PACKAGE_VERSION" Jan-16-2020"
#define PGM PACKAGE_NAME
#define URL "http://sarg.sourceforge.net"
